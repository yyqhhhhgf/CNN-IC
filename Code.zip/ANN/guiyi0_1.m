function [pn,minp,maxp,tn,mint,maxt]=guiyi0_1(p,t)

if nargin > 2
  nnerr.throw('Wrong number of arguments.');
end

minp = min(p')';
maxp = max(p')';
[R,Q]=size(p);
oneQ = ones(1,Q);

equal = minp==maxp;
nequal = ~equal;
if sum(equal) ~= 0
  warning('Some maximums and minimums are equal. Those inputs won''t be transformed.');
  minp0 = minp.*nequal - 1*equal;
  maxp0 = maxp.*nequal + 1*equal;
else
  minp0 = minp;
  maxp0 = maxp;
end

pn=(p-minp0*oneQ)./((maxp0-minp0)*oneQ);

if nargin==2
  mint = min(t')';
  maxt = max(t')';
  equal = mint==maxt;
  nequal = ~equal;
  if sum(equal) ~= 0
    warning('Some maximums and minimums are equal. Those targets won''t be transformed.');
    mint0 = mint.*nequal - 1*equal;
    maxt0 = maxt.*nequal + 1*equal;
  else
    mint0 = mint;
    maxt0 = maxt;
  end
  tn=(t-mint0*oneQ)./((maxt0-mint0)*oneQ);
end