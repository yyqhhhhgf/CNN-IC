function [pn] = tra_guiyi0_1(p,minp,maxp)
if nargin ~= 3
  nnerr.throw('Wrong number of arguments.');
end

equal = minp==maxp;
nequal = ~equal;
if sum(equal) ~= 0
  warning('Some maximums and minimums are equal. Those inputs won''t be transformed.');
  minp = minp.*nequal - 1*equal;
  maxp = maxp.*nequal + 1*equal;
end

[R,Q]=size(p);
oneQ = ones(1,Q);

pn =(p-minp*oneQ)./((maxp-minp)*oneQ);