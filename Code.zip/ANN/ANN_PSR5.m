%ANN Model of PSR at 5Hz
clear
clc

% import data
PHI=xlsread('BGR_PSR.xlsx',1);

%Divide the training set and testing set
 DA=randperm(49080);
PHI=PHI(DA,:);
PHI=PHI';
U1=PHI(3:15,1:47000);
Y1=PHI(17,1:47000);
U2=PHI(3:15,47001:end);
Y2=PHI(17,47001:end);

p=U1;
t=Y1;
k=U2;
yfactor=Y2;

% Data Normalization
[inputn,minpPSR5,maxpPSR5,outputn,mintPSR5,maxtPSR5]=guiyi0_1(p,t);
inputn_test=tra_guiyi0_1(k,minpPSR5,maxpPSR5);

%Structure of ANN
MSE=1e+5; %Inital minimize error
net0=newff(inputn,outputn,10,{'tansig','purelin'},'traingd');

%Training Setting
net0.trainParam.epochs=2000;         
net0.trainParam.lr=0.1;                  
net0.trainParam.goal=0.0001;                   
net0.trainParam.show=25;               
net0.trainParam.mc=0.05;               
net0.trainParam.min_grad=1e-6;      
net0.trainParam.max_fail=6;               

%Training Model
[net0,tr0]=train(net0,inputn,outputn);

%Model prediction
an0=sim(net0,inputn_test); 
test_simu0= post_guiyi0_1(an0,mintPSR5,maxtPSR5) 

error=test_simu0-yfactor;
R1=1-norm(error)^2/norm(yfactor-mean(yfactor))^2