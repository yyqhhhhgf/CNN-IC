% SVM Model of PH
clear 
clc

% load data
res=xlsread('TSMCOA_PH.xlsx',1);
res=res';
attributes =res(3:12,1:59049);
strength=res(14,1:59049);

%Divide the training set and testing set
w = randperm(size(attributes,2));
p_train = attributes(:,w(1:58000))';
t_train = strength(:,w(1:58000))';
p_test = attributes(:,w(58001:end))';
t_test = strength(:,w(58001:end))';
 
% Data Normalization
[pn_train,inputps] = mapminmax(p_train');
pn_train = pn_train';
pn_test = mapminmax('apply',p_test',inputps);
pn_test = pn_test';
[tn_train,outputps] = mapminmax(t_train');
tn_train = tn_train';
tn_test = mapminmax('apply',t_test',outputps);
tn_test = tn_test';

% c��g parameters setting
[c,g] = meshgrid(-10:20:10,-10:20:10);
[m,n] = size(c);
cg = zeros(m,n);  
eps = 10^(-2);
v = 5;
bestc = 0;
bestg = 0;
error = Inf;
 i = 1;
  j = 1;
        cmd = ['-v ',num2str(v),' -t 2',' -c ',num2str(2^c(i,j)),' -g ',num2str(2^g(i,j) ),' -s 3 -p 0.1'];
        cg(i,j) = svmtrain(tn_train,pn_train,cmd);
        if cg(i,j) < error
            error = cg(i,j);
            bestc = 2^c(i,j);
            bestg = 2^g(i,j);
        end
        if abs(cg(i,j) - error) <= eps && bestc > 2^c(i,j)
            error = cg(i,j);
            bestc = 2^c(i,j);
            bestg = 2^g(i,j);
        end
 
%SVM Model Training 
cmd = [' -t 2',' -c ',num2str(bestc),' -g ',num2str(bestg),' -s 3 -p 0.01'];
tic
model = svmtrain(tn_train,pn_train,cmd);
toc 
%SVM Model Prediction
[Predict_1,error_1,decision_values1] = svmpredict(tn_train,pn_train,model);
[Predict_2,error_2,decision_values2] = svmpredict(tn_test,pn_test,model);

predict_1 = mapminmax('reverse',Predict_1,outputps);
predict_2 = mapminmax('reverse',Predict_2,outputps);
 
result_1 = [t_train predict_1];
result_2 = [t_test predict_2];
 
%Figure
figure(1)
plot(1:100,t_train(1:100),'r-*',1:100,predict_1(1:100),'b:o')
grid on
legend('Actual','Predict')
xlabel('Sample')
string_1 = {'Comparison';
           ['mse = ' num2str(error_1(2)) ' R^2 = ' num2str(error_1(3))]};
title(string_1)
figure(2)
plot(1:100,t_test(100),'r-*',1:100,predict_2(1:100),'b:o')
grid on
legend('Actual','Predict')
xlabel('Sample')
string_2 = {'Comparison';
           ['mse = ' num2str(error_2(2)) ' R^2 = ' num2str(error_2(3))]};
title(string_2)
