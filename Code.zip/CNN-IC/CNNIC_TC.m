%CNN-IC Model for TC
close all   
clear       
clc         

% import data

res=xlsread('BGR_TC.xlsx',1);

%Divide the training set and testing set

temp = randperm(46596);
res=res(temp,:);
res=res';
P_train = res(3:15,1:45000);
T_train = res(17,1:45000);
M = size(P_train,2);
P_test = res(3:15,45001:end);
T_test = res(17,45001:end);
N= size(P_test,2);

% Data Normalization
[pn,minpTC,maxpTC,tn,mintTC,maxtTC]=guiyi0_1(P_train,T_train);
kn=tra_guiyi0_1(P_test,minpTC,maxpTC);
mn=tra_guiyi0_1(T_test,mintTC,maxtTC);

%Sparse topology mapping

D=zeros(8,9,45000);
D(3,1,:)=pn(9,:);
D(4,1,:)=pn(4,:);
D(5,1,:)=pn(8,:);
D(6,1,:)=pn(3,:);
D(7,2,:)=pn(3,:);
D(8,2,:)=pn(8,:);
D(3,3,:)=pn(9,:);
D(4,3,:)=pn(4,:);
D(5,3,:)=pn(8,:);
D(6,3,:)=pn(3,:);
D(3,4,:)=pn(11,:);
D(4,4,:)=pn(6,:);
D(7,4,:)=pn(12,:);
D(8,4,:)=pn(7,:);
D(1,5,:)=pn(13,:);
D(2,5,:)=1;
D(3,5,:)=pn(13,:);
D(4,5,:)=1;
D(1,6,:)=pn(13,:);
D(2,6,:)=1;
D(3,6,:)=pn(13,:);
D(4,6,:)=1;
D(1,7,:)=pn(13,:);
D(2,7,:)=1;
D(3,7,:)=pn(13,:);
D(4,7,:)=1;
D(5,7,:)=1;
D(6,7,:)=pn(2,:);
D(1,8,:)=pn(13,:);
D(2,8,:)=1;
D(3,8,:)=pn(13,:);
D(4,8,:)=1;
D(1,9,:)=pn(13,:);
D(2,9,:)=1;
D(3,9,:)=pn(13,:);
D(4,9,:)=1;
D(5,9,:)=1;
D(6,9,:)=pn(1,:);
E=zeros(8,9,1596);
E(3,1,:)=kn(9,:);
E(4,1,:)=kn(4,:);
E(5,1,:)=kn(8,:);
E(6,1,:)=kn(3,:);
E(7,2,:)=kn(3,:);
E(8,2,:)=kn(8,:);
E(3,3,:)=kn(9,:);
E(4,3,:)=kn(4,:);
E(5,3,:)=kn(8,:);
E(6,3,:)=kn(3,:);
E(3,4,:)=kn(11,:);
E(4,4,:)=kn(6,:);
E(7,4,:)=kn(12,:);
E(8,4,:)=kn(7,:);
E(1,5,:)=kn(13,:);
E(2,5,:)=1;
E(3,5,:)=kn(13,:);
E(4,5,:)=1;
E(1,6,:)=kn(13,:);
E(2,6,:)=1;
E(3,6,:)=kn(13,:);
E(4,6,:)=1;
E(1,7,:)=kn(13,:);
E(2,7,:)=1;
E(3,7,:)=kn(13,:);
E(4,7,:)=1;
E(5,7,:)=1;
E(6,7,:)=kn(2,:);
E(1,8,:)=kn(13,:);
E(2,8,:)=1;
E(3,8,:)=kn(13,:);
E(4,8,:)=1;
E(1,9,:)=kn(13,:);
E(2,9,:)=1;
E(3,9,:)=kn(13,:);
E(4,9,:)=1;
E(5,9,:)=1;
E(6,9,:)=kn(1,:);

%Data tiling  

p_train =double(reshape(D,8,9,1,M));
p_test = double(reshape(E,8,9,1,N));
t_train = double(tn)';
t_test = double(mn)';

%Structure of CNN

layers = [
  imageInputLayer( [8,9,1])     
  convolution2dLayer([5,5],32,'Padding','same') 
  batchNormalizationLayer
  reluLayer                  
  maxPooling2dLayer([2,2],'Padding','same','Stride',1) 
  convolution2dLayer([5,5],64,'Padding','same') 
  batchNormalizationLayer
  reluLayer                    
  maxPooling2dLayer([2,2],'Padding','same','Stride',1)
  convolution2dLayer([5,5],128,'Padding','same') 
  batchNormalizationLayer
  reluLayer                 
  maxPooling2dLayer([2,2],'Padding','same','Stride',1)
  fullyConnectedLayer(60)       
  reluLayer
  fullyConnectedLayer(40)       
  reluLayer
  fullyConnectedLayer(40)
  reluLayer
  fullyConnectedLayer(1)        
  regressionLayer ];    

%Training parameters setting

   options = trainingOptions('sgdm', ...  
   'MiniBatchSize',100, ...                 
   'MaxEpochs',50, ...                    
   'InitialLearnRate',0.003, ...           
   'LearnRateSchedule','piecewise',...     
   'LearnRateDropFactor', 0.5, ...         
   'LearnRateDropPeriod',100, ...          
   'Shuffle','every-epoch', ...         
   'Plots','training-progress', ...       
   'Verbose',false,...
   'ValidationData',{p_test,t_test},...
   'VerboseFrequency',50);
 
 %Training Model
[net,info]=trainNetwork(p_train,t_train,layers,options);

%Model Prediction
t_sim1 = predict(net, p_test );
ytest1=post_guiyi0_1(t_sim1,mintTC,maxtTC);
error1=ytest1-T_test';
RMSE1 = sqrt(sum((error1).^2) ./ N);
disp(['RMSE:',num2str(RMSE1)])

%Calculation of relevant indicators
%Fitting Accuracy  R2

R2 = 1 - norm(T_test - ytest1').^2 /norm(T_test - mean(T_test)).^2;
disp(['R2:',num2str(R2)])

%MAE

mae1 = sum(abs(ytest1'-T_test))./ N ;
disp(['MAE: ', num2str(mae1)])

% MBE

mbe1=sum(ytest1' - T_test)./N;
disp(['MBE: ', num2str(mbe1)])


save CNN_TC net;