%CNN-IC Model for PC
close all   
clear       
clc         

% import data

res=xlsread('TSMCOA_PC.xlsx',1);

%Divide the training set and testing set

temp = randperm(59049);
res=res(temp,:);
res=res';
P_train = res(3:12,1:58000);
T_train = res(14,1:58000);
M = size(P_train,2);
P_test = res(3:12,58001:end);
T_test = res(14,58001:end);
N= size(P_test,2);

% Data Normalization
[pn,minpP,maxpP,tn,mintP,maxtP]=guiyi0_1(P_train,T_train);
kn=tra_guiyi0_1(P_test,minpP,maxpP);
mn=tra_guiyi0_1(T_test,mintP,maxtP);

%Sparse topology mapping 

D=zeros(6,4,58000);
D(1,1,:)=pn(2,:);
D(2,1,:)=pn(7,:);
D(3,1,:)=pn(1,:);
D(4,1,:)=pn(6,:);
D(5,2,:)=pn(3,:);
D(6,2,:)=pn(8,:);
D(1,3,:)=pn(2,:);
D(2,3,:)=pn(7,:);
D(3,3,:)=pn(1,:);
D(4,3,:)=pn(6,:);
D(1,4,:)=pn(4,:);
D(2,4,:)=pn(9,:);
D(5,4,:)=pn(5,:);
D(6,4,:)=pn(10,:);
E=zeros(6,4,1049);
E(1,1,:)=kn(2,:);
E(2,1,:)=kn(7,:);
E(3,1,:)=kn(1,:);
E(4,1,:)=kn(6,:);
E(5,2,:)=kn(3,:);
E(6,2,:)=kn(8,:);
E(1,3,:)=kn(2,:);
E(2,3,:)=kn(7,:);
E(3,3,:)=kn(1,:);
E(4,3,:)=kn(6,:);
E(1,4,:)=kn(4,:);
E(2,4,:)=kn(9,:);
E(5,4,:)=kn(5,:);
E(6,4,:)=kn(10,:);

%Data tiling  

p_train =double(reshape(D,6,4,1,M));
p_test = double(reshape(E,6,4,1,N));
t_train = double(tn)';
t_test = double(mn)';

%Structure of CNN

layers = [
  imageInputLayer( [6,4,1])    
  convolution2dLayer([3,3],32,'Padding','same') 
  batchNormalizationLayer
  leakyReluLayer                    
  maxPooling2dLayer([2,2],'Stride',1) 
  convolution2dLayer([3,3],64,'Padding','same') 
  batchNormalizationLayer
  leakyReluLayer                    
  maxPooling2dLayer([2,2],'Padding','same','Stride',1)
  convolution2dLayer([3,3],128,'Padding','same') 
  batchNormalizationLayer
  leakyReluLayer                   
  maxPooling2dLayer([2,2],'Padding','same','Stride',1)
  fullyConnectedLayer(50)        
  leakyReluLayer
  fullyConnectedLayer(50)        
  leakyReluLayer
  fullyConnectedLayer(50)
  leakyReluLayer
  fullyConnectedLayer(1)       
  regressionLayer];    

%Training parameters setting

   options = trainingOptions('sgdm', ...   
   'MiniBatchSize',100, ...                
   'MaxEpochs',50, ...                   
   'InitialLearnRate',0.01, ...           
   'LearnRateSchedule','piecewise',...     
   'LearnRateDropFactor', 0.5, ...         
   'LearnRateDropPeriod',100, ...     
   'Shuffle','every-epoch', ...            
   'Plots','training-progress', ...       
   'Verbose',false,...
   'ValidationData',{p_test,t_test},...
   'VerboseFrequency',1500);

 %Training Model
[net,info]=trainNetwork(p_train,t_train,layers,options);
%Model Prediction
t_sim1 = predict(net, p_test );
ytest1=post_guiyi0_1(t_sim1,mintP,maxtP);
error1=ytest1-T_test';
RMSE1 = sqrt(sum((error1).^2) ./ N);
disp(['RMSE:',num2str(RMSE1)])

%Calculation of relevant indicators
%Fitting Accuracy  R2

R2 = 1 - norm(T_test - ytest1').^2 /norm(T_test - mean(T_test)).^2;
disp(['R2:',num2str(R2)])

%MAE

mae1 = sum(abs(ytest1'-T_test))./ N ;
disp(['MAE: ', num2str(mae1)])

% MBE

mbe1=sum(ytest1' - T_test)./N;
disp(['MBE: ', num2str(mbe1)])

save CNN_P net;